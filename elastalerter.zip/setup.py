import setuptools

setuptools.setup(

    name = "elastalerter",
    version = "0.0.2",
    author = "",
    author_email = "jebidiah-anthony@github.com",
    description = "A simple alerter that returns the rule, id, and index.",
    url = "https://github.com/jebidiah-anthony/jebidiah-anthony.github.io/tree/master/prjct/files/elastalerter",
    packages = setuptools.find_packages(),
    classifiers = [
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent"
    ],
    python_requires = ">=3.6"
        
)
